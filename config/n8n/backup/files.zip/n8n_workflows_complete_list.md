# Complete N8N Workflows List - Alphabetical

**Total: 311 workflows**

---

1. A Very Simple _Human in the Loop_ Email Response System Using AI and IMAP
2. Actioning Your Meeting Next Steps using Transcripts and AI
3. Add positive feedback messages to a table in Notion
4. Advanced AI Demo (Presented at AI Developers #14 meetup)
5. Agentic Telegram AI bot with with LangChain nodes and new tools
6. AI agent chat
7. AI agent for Instagram DM_inbox. Manychat + Open AI integration
8. AI Agent for project management and meetings with Airtable and Fireflies
9. AI Agent for realtime insights on meetings
10. AI agent that can scrape webpages
11. AI Agent To Chat With Files In Supabase Storage
12. AI Agent to chat with Supabase_PostgreSQL DB
13. AI Agent to chat with you Search Console Data, using OpenAI and Postgres
14. AI Agent with Ollama for current weather and wiki
15. AI Agent _ Google calendar assistant using OpenAI
16. AI Automated HR Workflow for CV Analysis and Candidate Evaluation
17. AI chat with any data source (using the n8n workflow tool)
18. AI chatbot that can search the web
19. AI Crew to Automate Fundamental Stock Analysis - Q&A Workflow
20. AI Customer feedback sentiment analysis
21. AI Data Extraction with Dynamic Prompts and Airtable
22. AI Data Extraction with Dynamic Prompts and Baserow
23. AI Fitness Coach Strava Data Analysis and Personalized Training Insights
24. AI Powered Web Scraping with Jina, Google Sheets and OpenAI _ the EASY way
25. AI Social Media Caption Creator creates social media post captions in Airtable
26. AI Voice Chat using Webhook, Memory Manager, OpenAI, Google Gemini & ElevenLabs
27. AI Voice Chatbot with ElevenLabs & OpenAI for Customer Service and Restaurants
28. AI web researcher for sales
29. AI Youtube Trend Finder Based On Niche
30. AI-Generated Summary Block for WordPress Posts
31. AI-Powered Candidate Shortlisting Automation for ERPNext
32. AI-Powered Children_s Arabic Storytelling on Telegram
33. AI-Powered Children_s English Storytelling on Telegram with OpenAI
34. AI-Powered Email Automation for Business_ Summarize & Respond with RAG
35. AI-powered email processing autoresponder and response approval (Yes_No)
36. AI-Powered Information Monitoring with OpenAI, Google Sheets, Jina AI and Slack
37. AI-Powered RAG Workflow For Stock Earnings Report Analysis
38. AI-Powered Social Media Amplifier
39. AI-powered WooCommerce Support-Agent
40. AI_ Ask questions about any data source (using the n8n workflow retriever)
41. AI_ Summarize podcast episode and enhance using Wikipedia
42. Analyse papers from Hugging Face with AI and store them in Notion
43. Analyze & Sort Suspicious Email Contents with ChatGPT
44. Analyze feedback and send a message on Mattermost
45. Analyze feedback using AWS Comprehend and send it to a Mattermost channel
46. Analyze Suspicious Email Contents with ChatGPT Vision
47. Analyze tradingview.com charts with Chrome extension, N8N and OpenAI
48. Angie, Personal AI Assistant with Telegram Voice and Text
49. API Schema Extractor
50. Ask a human for help when the AI doesn_t know the answer
51. Ask questions about a PDF using AI
52. Author and Publish Blog Posts From Google Sheets
53. Auto Categorise Outlook Emails with AI
54. Auto-Categorize blog posts in wordpress using A.I.
55. Auto-label incoming Gmail messages with AI nodes
56. Auto-Tag Blog Posts in WordPress with AI
57. Automate Blog Creation in Brand Voice with AI
58. Automate Content Generator for WordPress with DeepSeek R1
59. Automate Customer Support Issue Resolution using AI Text Classifier
60. Automate Image Validation Tasks using AI Vision
61. Automate LinkedIn Outreach with Notion and OpenAI
62. Automate Pinterest Analysis & AI-Powered Content Suggestions With Pinterest API
63. Automate Sales Meeting Prep with AI & APIFY Sent To WhatsApp
64. Automate Screenshots with URLbox & Analyze them with AI
65. Automate SIEM Alert Enrichment with MITRE ATT&CK, Qdrant & Zendesk in n8n
66. Automate testimonials in Strapi with n8n
67. Automate Your RFP Process with OpenAI Assistants
68. Automated AI image analysis and response via Telegram
69. Automated End-to-End Fine-Tuning of OpenAI Models with Google Drive Integration
70. Automated Hugging Face Paper Summary Fetching & Categorization Workflow
71. Automated n8n Workflow Backup to GitHub with Deletion Tracking
72. Automated Workflow Backup System with Google Drive, Gmail and Discord Alerts
73. Automated_YouTube_Video_Scheduling___AI_Metadata_Generation___
74. Automate_YouTube_Uploads_with_AI_Generated_Metadata_from_Google_Drive
75. Automatic Background Removal for Images in Google Drive
76. Automatically_document_and_backup_N8N_workflows
77. Autonomous AI crawler
78. Backup_all_n8n_workflows_to_Google_Drive_every_4_hours
79. BambooHR AI-Powered Company Policies and Benefits Chatbot
80. Basic Automatic Gmail Email Labelling with OpenAI and Gmail API
81. Bitrix24 Chatbot Application Workflow example with Webhook Integration
82. Bitrix_Agent
83. Brave_Agent___MCP_1
84. Breakdown Documents into Study Notes using Templating MistralAI and Qdrant
85. Build a Financial Documents Assistant using Qdrant and Mistral.ai
86. Build a Tax Code Assistant with Qdrant, Mistral.ai and OpenAI
87. Build an OpenAI Assistant with Google Drive Integration
88. Build Your Own Image Search Using AI Object Detection, CDN and ElasticSearch
89. Building RAG Chatbot for Movie Recommendations with Qdrant and Open AI
90. Building Your First WhatsApp Chatbot
91. Chat Assistant (OpenAI assistant) with Postgres Memory And API Calling Capabalities
92. Chat with a Google Sheet using AI
93. Chat with GitHub API Documentation_ RAG-Powered Chatbot with Pinecone & OpenAI
94. Chat with local LLMs using n8n and Ollama
95. Chat with OpenAI Assistant (by adding a memory)
96. Chat with OpenAIs GPT via a simple Telegram Bot
97. Chat with PDF docs using AI (quoting sources)
98. Chat with Postgresql Database
99. Chat with your event schedule from Google Sheets in Telegram
100. ChatGPT Automatic Code Review in Gitlab MR
101. Classify lemlist replies using OpenAI and automate reply handling
102. Classify new bugs in Linear with OpenAI_s GPT-4 and move them to the right team
103. Complete business WhatsApp AI-Powered RAG Chatbot using OpenAI
104. Compose reply draft in Gmail with OpenAI Assistant
105. Configure your own Image Creation API Using OpenAI DALLE-3
106. Conversational Interviews with AI Agents and n8n Forms
107. Convert text to speech with OpenAI
108. Convert URL HTML to Markdown Format and Get Page Links
109. Create a Branded AI-Powered Website Chatbot
110. Create a Google Analytics Data Report with AI and sent it to E-Mail and Telegram
111. Create dynamic Twitter profile banner
112. create e-mail responses with fastmail and OpenAI
113. Create, update, and get a profile in Humantic AI
114. Creating a AI Slack Bot with Google Gemini
115. Custom LangChain agent written in JavaScript
116. Customer Insights with Qdrant, Python and Information Extractor
117. Customer Support Channel and Ticketing System with Slack and Linear
118. CV Resume PDF Parsing with Multimodal Vision AI
119. CV Screening with OpenAI
120. Daily meetings summarization with Gemini AI
121. Daily Podcast Summary
122. Deduplicate Scraping AI Grants for Eligibility using AI
123. Detect hallucinations using specialised Ollama model bespoke-minicheck
124. Discord AI-powered bot
125. Dynamically generate a webpage from user request using OpenAI Structured Output
126. Easy Image Captioning with Gemini 1.5 Pro
127. Effortless Email Management with AI-Powered Summarization & Review
128. Email Subscription Service with n8n Forms, Airtable and AI
129. Email Summary Agent
130. Enhance Customer Chat by Buffering Messages with Twilio and Redis
131. Enhance Security Operations with the Qualys Slack Shortcut Bot!
132. Enrich FAQ sections on your website pages at scale with AI
133. Enrich Pipedrive_s Organization Data with OpenAI GPT-4o & Notify it in Slack
134. Enrich Property Inventory Survey with Image Recognition and AI Agent
135. ETL pipeline for text processing
136. Extract and process information directly from PDF using Claude and Gemini
137. Extract data from resume and create PDF with Gotenberg
138. Extract Information from a Logo Sheet using forms, AI, Google Sheet and Airtable
139. Extract insights & analyse YouTube comments via AI Agent chat
140. Extract license plate number from image uploaded via an n8n form
141. Extract personal data with self-hosted LLM Mistral NeMo
142. Extract spending history from gmail to google sheet
143. Extract text from PDF and image using Vertex AI (Gemini) into CSV
144. Fetch Dynamic Prompts from GitHub and Auto-Populate n8n Expressions in Prompt
145. Flux AI Image Generator
146. Flux Dev Image Generation (Fal.ai) to Google Drive
147. Force AI to use a specific output format
148. Fully Automated AI Video Generation & Multi-Platform Publishing
149. Generate 9_16 Images from Content and Brand Guidelines
150. Generate audio from text using OpenAI and Webhook _ Text to Speech Workflow
151. Generate Instagram Content from Top Trends with AI Image Generation
152. Generate SEO Seed Keywords Using AI
153. Generate SQL queries from schema only - AI-powered
154. Generate Text-to-Speech Using Elevenlabs via API
155. Generate___Auto_post_AI_Videos_to_Social_Media_with_Veo3_and_Blotato
156. Generating Image Embeddings via Textual Summarisation
157. Get Airtable data via AI and Obsidian Notes
158. Gmail AI Auto-Responder_ Create Draft Replies to incoming emails
159. Hacker News Job Listing Scraper and Parser
160. Hacker News Throwback Machine - See What Was Hot on This Day, Every Year!
161. Hacker News to Video Content
162. Handling Appointment Leads and Follow-up With Twilio, Cal.com and AI
163. Handling Job Application Submissions with AI and n8n Forms
164. HR & IT Helpdesk Chatbot with Audio Transcription
165. HR Job Posting and Evaluation with AI
166. Image Creation with OpenAI and Telegram
167. Integrating AI with Open-Meteo API for Enhanced Weather Forecasting
168. Intelligent Web Query and Semantic Re-Ranking Flow using Brave and Google Gemini
169. Introduction to the HTTP Tool
170. Invoice data extraction with LlamaParse and OpenAI
171. IT Ops AI SlackBot Workflow - Chat with your knowledge base
172. KB Tool - Confluence Knowledge Base
173. Kids_Story_Building_System_v1_0_0
174. Learn Anything from HN - Get Top Resource Recommendations from Hacker News
175. LightRAG_Request
176. LINE Assistant with Google Calendar and Gmail Integration
177. Make OpenAI Citation for File Retrieval RAG
178. Manipulate PDF with Adobe developer API
179. Microsoft Outlook AI Email Assistant with contact support from Monday and Airtable
180. Modular & Customizable AI-Powered Email Routing_ Text Classifier for eCommerce
181. MongoDB AI Agent - Intelligent Movie Recommendations
182. Monthly Spotify Track Archiving and Playlist Classification
183. n8n_1_1__Replicate_Image_Generator
184. n8n_1_1__Telegram_Voice_Agent
185. n8n_2_1__Content_Team___Notion
186. n8n_2_2__Google_Sheets_Invoice_Parser
187. n8n_2_3__Airtable_Workflow
188. n8n_2_4__Airtable_Invoice_Workflow
189. n8n_2_5__Telegram_Long_Term_Memory
190. n8n_3_1__SearXNG_Tool___Think
191. n8n_3_1__SearXNG_Tool___Think__Image
192. n8n_3_2__c4ai___Local_Supabase
193. n8n_3_3__Perplexity
194. n8n_3_3__Perplexity_1
195. n8n_3_41__GraphQL
196. n8n_3_4__GraphQL
197. n8n_3_4__Redis
198. n8n_3_5__Replicate
199. n8n_3_6__Flux_Redis_Master_Bot
200. n8n_3_6__Flux_Redis_Worker
201. n8n_4_1__Qdrant
202. n8n_4_2__c4ai___Local_Supabase_RAG
203. n8n_4_3__Deep_Research
204. Narrating over a Video using Multimodal AI
205. Notion AI Assistant Generator
206. Notion knowledge base AI assistant
207. Notion to Pinecone Vector Store Integration
208. Obsidian Notes Read Aloud using AI_ Available as a Podcast Feed
209. Open Deep Research - AI-Powered Autonomous Research Workflow
210. OpenAI assistant with custom tools
211. OpenAI Assistant workflow_ upload file, create an Assistant, chat with it!
212. OpenAI examples_ ChatGPT, DALLE-2, Whisper-1 – 5-in-1
213. OpenAI-powered tweet generator
214. Optimize & Update Printify Title and Description Workflow
215. Organise Your Local File Directories With AI
216. Personal Shopper Chatbot for WooCommerce with RAG using Google Drive and openAI
217. Post New YouTube Videos to X
218. Prepare CSV files with GPT-4
219. Prompt-based Object Detection with Gemini 2.0
220. Proxmox AI Agent with n8n and Generative AI Integration
221. Qualify new leads in Google Sheets via OpenAI_s GPT-4
222. Qualify replies from Pipedrive persons with AI
223. Qualifying Appointment Requests with AI & n8n Forms
224. Query n8n Credentials with AI SQL Agent
225. Query Perplexity AI from your n8n workflows
226. RAG Chatbot for Company Documents using Google Drive and Gemini
227. RAG_Context-Aware Chunking _ Google Drive to Pinecone via OpenRouter & Gemini
228. Reconcile Rent Payments with Local Excel Spreadsheet and OpenAI
229. Reddit AI digest
230. Remove Personally Identifiable Information (PII) from CSV Files with OpenAI
231. Respond to WhatsApp Messages with AI Like a Pro!
232. Scrape and summarize posts of a news site without RSS feed using AI and save them to a NocoDB
233. Scrape and summarize webpages with AI
234. Scrape Trustpilot Reviews with DeepSeek, Analyze Sentiment with OpenAI
235. Screen Applicants With AI, notify HR and save them in a Google Sheet
236. Send a ChatGPT email reply and save responses to Google Sheets
237. Send a random recipe once a day to Telegram
238. Send daily translated Calvin and Hobbes Comics to Discord
239. Send Google analytics data to A.I. to analyze then save results in Baserow
240. Send Google analytics data to A.I. to analyze then save results in Baserow (duplicate)
241. Send specific PDF attachments from Gmail to Google Drive using OpenAI
242. Sentiment Analysis Tracking on Support Issues with Linear and Slack
243. Share YouTube Videos with AI Summaries on Discord
244. Simple Expense Tracker with n8n Chat, AI Agent and Google Sheets
245. Siri AI Agent_ Apple Shortcuts powered voice template
246. Slack slash commands AI Chat Bot
247. Social Media Analysis and Automated Email Generation
248. Speed Up Social Media Banners With BannerBear.com
249. Spot Workplace Discrimination Patterns with AI
250. Store Notion_s Pages as Vector Documents into Supabase with OpenAI
251. Suggest meeting slots using AI
252. Summarize Google Sheets form feedback via OpenAI_s GPT-4
253. Summarize SERPBear data with AI (via Openrouter) and save it to Baserow
254. Summarize the New Documents from Google Drive and Save Summary in Google Sheet
255. Summarize Umami data with AI (via Openrouter) and save it to Baserow
256. Summarize your emails with A.I. (via Openrouter) and send to Line messenger
257. Summarize YouTube Videos from Transcript
258. Supabase Insertion & Upsertion & Retrieval
259. Supabase Vector Updater
260. Survey Insights with Qdrant, Python and Information Extractor
261. Talk to your SQLite database with a LangChain AI Agent
262. Telegram AI bot assistant_ ready-made template for voice & text messages
263. Telegram AI bot with LangChain nodes
264. Telegram AI Bot_ NeurochainAI Text & Image - NeurochainAI Basic API Integration
265. Telegram AI Chatbot
266. Telegram Bot with Supabase memory and OpenAI assistant integration
267. Telegram chat with PDF
268. Telegram to Spotify with OpenAI
269. Text automations using Apple Shortcuts
270. Transcribe Audio Files, Summarize with GPT-4, and Store in Notion
271. Transcribing Bank Statements To Markdown Using Gemini Vision AI
272. Transform Image to Lego Style Using Line and Dall-E
273. Translate audio using AI
274. Translate Telegram audio messages with AI (55 supported languages)
275. Turn Emails into AI-Enhanced Tasks in Notion (Multi-User Support) with Gmail, Airtable and Softr
276. Twitter Virtual AI Influencer
277. Ultimate Scraper Workflow for n8n
278. Update Twitter banner using HTTP request
279. Upload to Instagram and Tiktok from Google Drive
280. Upsert huge documents in a vector store with Supabase and Notion
281. Use AI to organize your Todoist Inbox
282. Use OpenRouter in n8n versions _1.78
283. Using External Workflows as Tools in n8n
284. UTM Link Creator & QR Code Generator with Scheduled Google Analytics Reports
285. V1_Local_RAG_AI_Agent
286. V2_Local_Supabase_RAG_AI_Agent
287. V3_Local_Agentic_RAG_AI_Agent
288. vAssistant for Hubspot Chat using OpenAi and Airtable
289. Vector Database as a Big Data Analysis Tool for AI Agents [1_3 anomaly][1_2 KNN]
290. Vector Database as a Big Data Analysis Tool for AI Agents [2_2 KNN]
291. Vector Database as a Big Data Analysis Tool for AI Agents [2_3 - anomaly]
292. Vector Database as a Big Data Analysis Tool for AI Agents [3_3 - anomaly]
293. Venafi Cloud Slack Cert Bot
294. Visual Regression Testing with Apify and AI Vision Model
295. Visualize your SQL Agent queries with OpenAI and Quickchart.io
296. WordPress - AI Chatbot to enhance user experience - with Supabase and OpenAI
297. Write a WordPress post with AI (starting from a few keywords)
298. Zoom AI Meeting Assistant creates mail summary, ClickUp tasks and follow-up call
299. ⚡AI-Powered YouTube Video Summarization & Analysis
300. ✨ Vision-Based AI Agent Scraper - with Google Sheets, ScrapingBee, and Gemini
301. 🎨 Interactive Image Editor with FLUX.1 Fill Tool for Inpainting
302. 🐋DeepSeek V3 Chat & R1 Reasoning Quick Start
303. 🐋🤖 DeepSeek AI Agent + Telegram + LONG TERM Memory 🧠
304. 📈 Receive Daily Market News from FT.com to your Microsoft outlook inbox
305. 📚 Auto-generate documentation for n8n workflows with GPT and Docsify
306. 🔐🦙🤖 Private & Local Ollama Self-Hosted AI Assistant
307. 🔥📈🤖 AI Agent for n8n Creators Leaderboard - Find Popular Workflows
308. 🚀 Local Multi-LLM Testing & Performance Tracker
309. 🤖 Telegram Messaging Agent for Text_Audio_Images
310. 🤖🧑_💻 AI Agent for Top n8n Creators Leaderboard Reporting
311. 🤖🧠 AI Agent Chatbot + LONG TERM Memory + Note Storage + Telegram

---

*Complete list of all n8n workflows in your collection*
*Last updated: October 25, 2025*
