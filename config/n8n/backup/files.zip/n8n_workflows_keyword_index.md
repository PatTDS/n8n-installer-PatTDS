# N8N Workflows - Searchable Keyword Index

## Quick Search Guide

Search for keywords below to find relevant workflows.

---

## A

### Airtable (12 workflows)
- AI Agent for project management and meetings with Airtable and Fireflies
- AI Data Extraction with Dynamic Prompts and Airtable
- AI Social Media Caption Creator creates social media post captions in Airtable
- Email Subscription Service with n8n Forms, Airtable and AI
- Get Airtable data via AI and Obsidian Notes
- Microsoft Outlook AI Email Assistant with contact support from Monday and Airtable
- Turn Emails into AI-Enhanced Tasks in Notion (Multi-User Support) with Gmail, Airtable and Softr
- n8n_2_3__Airtable_Workflow
- n8n_2_4__Airtable_Invoice_Workflow
- vAssistant for Hubspot Chat using OpenAi and Airtable

### Analytics (8 workflows)
- Create a Google Analytics Data Report with AI and sent it to E-Mail and Telegram
- Send Google analytics data to A.I. to analyze then save results in Baserow (2 versions)
- Social Media Analysis and Automated Email Generation
- Summarize SERPBear data with AI (via Openrouter) and save it to Baserow
- Summarize Umami data with AI (via Openrouter) and save it to Baserow
- UTM Link Creator & QR Code Generator with Scheduled Google Analytics Reports

### API (5 workflows)
- API Schema Extractor
- Chat with GitHub API Documentation_ RAG-Powered Chatbot with Pinecone & OpenAI
- Configure your own Image Creation API Using OpenAI DALLE-3
- Generate Text-to-Speech Using Elevenlabs via API
- Integrating AI with Open-Meteo API for Enhanced Weather Forecasting

### Audio/Voice (15 workflows)
- AI Voice Chat using Webhook, Memory Manager, OpenAI, Google Gemini & ElevenLabs
- AI Voice Chatbot with ElevenLabs & OpenAI for Customer Service and Restaurants
- Angie, Personal AI Assistant with Telegram Voice and Text
- Convert text to speech with OpenAI
- Generate audio from text using OpenAI and Webhook _ Text to Speech Workflow
- Generate Text-to-Speech Using Elevenlabs via API
- HR & IT Helpdesk Chatbot with Audio Transcription
- Obsidian Notes Read Aloud using AI_ Available as a Podcast Feed
- Siri AI Agent_ Apple Shortcuts powered voice template
- Transcribe Audio Files, Summarize with GPT-4, and Store in Notion
- Translate audio using AI
- Translate Telegram audio messages with AI (55 supported languages)
- n8n_1_1__Telegram_Voice_Agent
- 🤖 Telegram Messaging Agent for Text_Audio_Images

### Automation (20+ workflows)
- Automate Blog Creation in Brand Voice with AI
- Automate Content Generator for WordPress with DeepSeek R1
- Automate Customer Support Issue Resolution using AI Text Classifier
- Automate Image Validation Tasks using AI Vision
- Automate LinkedIn Outreach with Notion and OpenAI
- Automate Pinterest Analysis & AI-Powered Content Suggestions With Pinterest API
- Automate Sales Meeting Prep with AI & APIFY Sent To WhatsApp
- Automate Screenshots with URLbox & Analyze them with AI
- Automate SIEM Alert Enrichment with MITRE ATT&CK, Qdrant & Zendesk in n8n
- Automate testimonials in Strapi with n8n
- Automate Your RFP Process with OpenAI Assistants
- Automated AI image analysis and response via Telegram
- Automated End-to-End Fine-Tuning of OpenAI Models with Google Drive Integration
- Automated Hugging Face Paper Summary Fetching & Categorization Workflow
- Automated n8n Workflow Backup to GitHub with Deletion Tracking
- Automated Workflow Backup System with Google Drive, Gmail and Discord Alerts
- Automated_YouTube_Video_Scheduling___AI_Metadata_Generation___
- Automate_YouTube_Uploads_with_AI_Generated_Metadata_from_Google_Drive
- Automatic Background Removal for Images in Google Drive

---

## B

### Backup (6 workflows)
- Automated n8n Workflow Backup to GitHub with Deletion Tracking
- Automated Workflow Backup System with Google Drive, Gmail and Discord Alerts
- Automatically_document_and_backup_N8N_workflows
- Backup_all_n8n_workflows_to_Google_Drive_every_4_hours

### Blog/Content (10 workflows)
- AI-Generated Summary Block for WordPress Posts
- Auto-Categorize blog posts in wordpress using A.I.
- Auto-Tag Blog Posts in WordPress with AI
- Automate Blog Creation in Brand Voice with AI
- Automate Content Generator for WordPress with DeepSeek R1
- Author and Publish Blog Posts From Google Sheets
- Write a WordPress post with AI (starting from a few keywords)

---

## C

### Calendar (3 workflows)
- AI Agent _ Google calendar assistant using OpenAI
- Chat with your event schedule from Google Sheets in Telegram
- LINE Assistant with Google Calendar and Gmail Integration

### Chatbot (30+ workflows)
- AI agent chat
- AI chatbot that can search the web
- BambooHR AI-Powered Company Policies and Benefits Chatbot
- Bitrix24 Chatbot Application Workflow example with Webhook Integration
- Building Your First WhatsApp Chatbot
- Chat with a Google Sheet using AI
- Chat with GitHub API Documentation_ RAG-Powered Chatbot with Pinecone & OpenAI
- Chat with local LLMs using n8n and Ollama
- Chat with OpenAI Assistant (by adding a memory)
- Chat with OpenAIs GPT via a simple Telegram Bot
- Chat with PDF docs using AI (quoting sources)
- Chat with Postgresql Database
- Complete business WhatsApp AI-Powered RAG Chatbot using OpenAI
- Create a Branded AI-Powered Website Chatbot
- HR & IT Helpdesk Chatbot with Audio Transcription
- IT Ops AI SlackBot Workflow - Chat with your knowledge base
- Personal Shopper Chatbot for WooCommerce with RAG using Google Drive and openAI
- RAG Chatbot for Company Documents using Google Drive and Gemini
- Slack slash commands AI Chat Bot
- Telegram AI Chatbot
- WordPress - AI Chatbot to enhance user experience - with Supabase and OpenAI

### Claude (1 workflow)
- Extract and process information directly from PDF using Claude and Gemini

### Customer Support (15 workflows)
- AI Voice Chatbot with ElevenLabs & OpenAI for Customer Service and Restaurants
- AI-powered WooCommerce Support-Agent
- Automate Customer Support Issue Resolution using AI Text Classifier
- Customer Insights with Qdrant, Python and Information Extractor
- Customer Support Channel and Ticketing System with Slack and Linear
- Enhance Customer Chat by Buffering Messages with Twilio and Redis
- Sentiment Analysis Tracking on Support Issues with Linear and Slack

### CV/Resume (4 workflows)
- AI Automated HR Workflow for CV Analysis and Candidate Evaluation
- CV Resume PDF Parsing with Multimodal Vision AI
- CV Screening with OpenAI
- Extract data from resume and create PDF with Gotenberg

---

## D

### Database (15 workflows)
- AI Agent to chat with Supabase_PostgreSQL DB
- AI Agent to chat with you Search Console Data, using OpenAI and Postgres
- Chat Assistant (OpenAI assistant) with Postgres Memory And API Calling Capabalities
- Chat with Postgresql Database
- MongoDB AI Agent - Intelligent Movie Recommendations
- Query n8n Credentials with AI SQL Agent
- Store Notion_s Pages as Vector Documents into Supabase with OpenAI
- Supabase Insertion & Upsertion & Retrieval
- Supabase Vector Updater
- Talk to your SQLite database with a LangChain AI Agent
- Telegram Bot with Supabase memory and OpenAI assistant integration
- Upsert huge documents in a vector store with Supabase and Notion
- Vector Database as a Big Data Analysis Tool for AI Agents (4 versions)

### DeepSeek (4 workflows)
- Automate Content Generator for WordPress with DeepSeek R1
- Scrape Trustpilot Reviews with DeepSeek, Analyze Sentiment with OpenAI
- 🐋DeepSeek V3 Chat & R1 Reasoning Quick Start
- 🐋🤖 DeepSeek AI Agent + Telegram + LONG TERM Memory 🧠

### Discord (3 workflows)
- Discord AI-powered bot
- Send daily translated Calvin and Hobbes Comics to Discord
- Share YouTube Videos with AI Summaries on Discord

### Document Processing (25+ workflows)
- AI Agent To Chat With Files In Supabase Storage
- Ask questions about a PDF using AI
- Breakdown Documents into Study Notes using Templating MistralAI and Qdrant
- Build a Financial Documents Assistant using Qdrant and Mistral.ai
- Chat with PDF docs using AI (quoting sources)
- Extract and process information directly from PDF using Claude and Gemini
- Extract data from resume and create PDF with Gotenberg
- Extract text from PDF and image using Vertex AI (Gemini) into CSV
- Invoice data extraction with LlamaParse and OpenAI
- Manipulate PDF with Adobe developer API
- RAG Chatbot for Company Documents using Google Drive and Gemini
- Send specific PDF attachments from Gmail to Google Drive using OpenAI
- Telegram chat with PDF

---

## E

### Email (25+ workflows)
- A Very Simple _Human in the Loop_ Email Response System Using AI and IMAP
- AI-Powered Email Automation for Business_ Summarize & Respond with RAG
- AI-powered email processing autoresponder and response approval (Yes_No)
- Analyze & Sort Suspicious Email Contents with ChatGPT
- Analyze Suspicious Email Contents with ChatGPT Vision
- Auto Categorise Outlook Emails with AI
- Auto-label incoming Gmail messages with AI nodes
- Basic Automatic Gmail Email Labelling with OpenAI and Gmail API
- Compose reply draft in Gmail with OpenAI Assistant
- create e-mail responses with fastmail and OpenAI
- Effortless Email Management with AI-Powered Summarization & Review
- Email Subscription Service with n8n Forms, Airtable and AI
- Email Summary Agent
- Extract spending history from gmail to google sheet
- Gmail AI Auto-Responder_ Create Draft Replies to incoming emails
- LINE Assistant with Google Calendar and Gmail Integration
- Microsoft Outlook AI Email Assistant with contact support from Monday and Airtable
- Modular & Customizable AI-Powered Email Routing_ Text Classifier for eCommerce
- Send a ChatGPT email reply and save responses to Google Sheets
- Summarize your emails with A.I. (via Openrouter) and send to Line messenger
- Turn Emails into AI-Enhanced Tasks in Notion (Multi-User Support) with Gmail, Airtable and Softr

### Extraction (15 workflows)
- AI Data Extraction with Dynamic Prompts and Airtable
- AI Data Extraction with Dynamic Prompts and Baserow
- Extract and process information directly from PDF using Claude and Gemini
- Extract data from resume and create PDF with Gotenberg
- Extract Information from a Logo Sheet using forms, AI, Google Sheet and Airtable
- Extract insights & analyse YouTube comments via AI Agent chat
- Extract license plate number from image uploaded via an n8n form
- Extract personal data with self-hosted LLM Mistral NeMo
- Extract spending history from gmail to google sheet
- Extract text from PDF and image using Vertex AI (Gemini) into CSV
- Invoice data extraction with LlamaParse and OpenAI

---

## F

### Forms (5 workflows)
- Conversational Interviews with AI Agents and n8n Forms
- Email Subscription Service with n8n Forms, Airtable and AI
- Extract Information from a Logo Sheet using forms, AI, Google Sheet and Airtable
- Handling Job Application Submissions with AI and n8n Forms
- Qualifying Appointment Requests with AI & n8n Forms

---

## G

### Gemini (10 workflows)
- AI Voice Chat using Webhook, Memory Manager, OpenAI, Google Gemini & ElevenLabs
- Creating a AI Slack Bot with Google Gemini
- Daily meetings summarization with Gemini AI
- Easy Image Captioning with Gemini 1.5 Pro
- Extract and process information directly from PDF using Claude and Gemini
- Extract text from PDF and image using Vertex AI (Gemini) into CSV
- Intelligent Web Query and Semantic Re-Ranking Flow using Brave and Google Gemini
- Prompt-based Object Detection with Gemini 2.0
- RAG Chatbot for Company Documents using Google Drive and Gemini
- Transcribing Bank Statements To Markdown Using Gemini Vision AI

### Google Drive (15+ workflows)
- Automate_YouTube_Uploads_with_AI_Generated_Metadata_from_Google_Drive
- Automated End-to-End Fine-Tuning of OpenAI Models with Google Drive Integration
- Automatic Background Removal for Images in Google Drive
- Backup_all_n8n_workflows_to_Google_Drive_every_4_hours
- Build an OpenAI Assistant with Google Drive Integration
- Fetch Dynamic Prompts from GitHub and Auto-Populate n8n Expressions in Prompt
- Flux Dev Image Generation (Fal.ai) to Google Drive
- Personal Shopper Chatbot for WooCommerce with RAG using Google Drive and openAI
- RAG Chatbot for Company Documents using Google Drive and Gemini
- RAG_Context-Aware Chunking _ Google Drive to Pinecone via OpenRouter & Gemini
- Send specific PDF attachments from Gmail to Google Drive using OpenAI
- Summarize the New Documents from Google Drive and Save Summary in Google Sheet
- Upload to Instagram and Tiktok from Google Drive

### Google Sheets (10+ workflows)
- AI Powered Web Scraping with Jina, Google Sheets and OpenAI _ the EASY way
- AI-Powered Information Monitoring with OpenAI, Google Sheets, Jina AI and Slack
- Author and Publish Blog Posts From Google Sheets
- Chat with a Google Sheet using AI
- Chat with your event schedule from Google Sheets in Telegram
- Extract Information from a Logo Sheet using forms, AI, Google Sheet and Airtable
- Qualify new leads in Google Sheets via OpenAI_s GPT-4
- Screen Applicants With AI, notify HR and save them in a Google Sheet
- Send a ChatGPT email reply and save responses to Google Sheets
- Simple Expense Tracker with n8n Chat, AI Agent and Google Sheets
- Summarize Google Sheets form feedback via OpenAI_s GPT-4
- ✨ Vision-Based AI Agent Scraper - with Google Sheets, ScrapingBee, and Gemini
- n8n_2_2__Google_Sheets_Invoice_Parser

---

## H

### HR/Recruitment (10 workflows)
- AI Automated HR Workflow for CV Analysis and Candidate Evaluation
- AI-Powered Candidate Shortlisting Automation for ERPNext
- BambooHR AI-Powered Company Policies and Benefits Chatbot
- CV Resume PDF Parsing with Multimodal Vision AI
- CV Screening with OpenAI
- Handling Job Application Submissions with AI and n8n Forms
- HR & IT Helpdesk Chatbot with Audio Transcription
- HR Job Posting and Evaluation with AI
- Screen Applicants With AI, notify HR and save them in a Google Sheet
- Spot Workplace Discrimination Patterns with AI

---

## I

### Image Generation (15 workflows)
- AI Social Media Caption Creator creates social media post captions in Airtable
- Automated AI image analysis and response via Telegram
- Automate Image Validation Tasks using AI Vision
- Build Your Own Image Search Using AI Object Detection, CDN and ElasticSearch
- Configure your own Image Creation API Using OpenAI DALLE-3
- Easy Image Captioning with Gemini 1.5 Pro
- Extract license plate number from image uploaded via an n8n form
- Flux AI Image Generator
- Flux Dev Image Generation (Fal.ai) to Google Drive
- Generate 9_16 Images from Content and Brand Guidelines
- Generate Instagram Content from Top Trends with AI Image Generation
- Generating Image Embeddings via Textual Summarisation
- Image Creation with OpenAI and Telegram
- Transform Image to Lego Style Using Line and Dall-E
- 🎨 Interactive Image Editor with FLUX.1 Fill Tool for Inpainting
- n8n_1_1__Replicate_Image_Generator

### Instagram (4 workflows)
- AI agent for Instagram DM_inbox. Manychat + Open AI integration
- Generate Instagram Content from Top Trends with AI Image Generation
- Upload to Instagram and Tiktok from Google Drive

---

## L

### LangChain (5 workflows)
- Agentic Telegram AI bot with with LangChain nodes and new tools
- Building RAG Chatbot for Movie Recommendations with Qdrant and Open AI
- Custom LangChain agent written in JavaScript
- Talk to your SQLite database with a LangChain AI Agent
- Telegram AI bot with LangChain nodes

### LinkedIn (1 workflow)
- Automate LinkedIn Outreach with Notion and OpenAI

---

## M

### Meeting Management (8 workflows)
- Actioning Your Meeting Next Steps using Transcripts and AI
- AI Agent for project management and meetings with Airtable and Fireflies
- AI Agent for realtime insights on meetings
- Automate Sales Meeting Prep with AI & APIFY Sent To WhatsApp
- Daily meetings summarization with Gemini AI
- Suggest meeting slots using AI
- Zoom AI Meeting Assistant creates mail summary, ClickUp tasks and follow-up call

### Memory (5 workflows)
- AI Voice Chat using Webhook, Memory Manager, OpenAI, Google Gemini & ElevenLabs
- Chat with OpenAI Assistant (by adding a memory)
- Telegram Bot with Supabase memory and OpenAI assistant integration
- n8n_2_5__Telegram_Long_Term_Memory
- 🐋🤖 DeepSeek AI Agent + Telegram + LONG TERM Memory 🧠
- 🤖🧠 AI Agent Chatbot + LONG TERM Memory + Note Storage + Telegram

### Mistral (3 workflows)
- Breakdown Documents into Study Notes using Templating MistralAI and Qdrant
- Build a Financial Documents Assistant using Qdrant and Mistral.ai
- Build a Tax Code Assistant with Qdrant, Mistral.ai and OpenAI
- Extract personal data with self-hosted LLM Mistral NeMo

---

## N

### Notion (8 workflows)
- Add positive feedback messages to a table in Notion
- Analyse papers from Hugging Face with AI and store them in Notion
- Automate LinkedIn Outreach with Notion and OpenAI
- Get Airtable data via AI and Obsidian Notes
- Notion AI Assistant Generator
- Notion knowledge base AI assistant
- Notion to Pinecone Vector Store Integration
- Store Notion_s Pages as Vector Documents into Supabase with OpenAI
- Transcribe Audio Files, Summarize with GPT-4, and Store in Notion
- Turn Emails into AI-Enhanced Tasks in Notion (Multi-User Support) with Gmail, Airtable and Softr
- Upsert huge documents in a vector store with Supabase and Notion
- n8n_2_1__Content_Team___Notion

---

## O

### Ollama (5 workflows)
- AI Agent with Ollama for current weather and wiki
- Chat with local LLMs using n8n and Ollama
- Detect hallucinations using specialised Ollama model bespoke-minicheck
- 🔐🦙🤖 Private & Local Ollama Self-Hosted AI Assistant

### OpenAI (100+ workflows) - Major Platform
Too many to list individually. Used in most AI workflows for:
- GPT-3.5/GPT-4 text generation
- DALL-E image generation
- Whisper speech-to-text
- Text-to-speech
- Assistants API
- Vision capabilities

---

## P

### PDF Processing (15 workflows)
- Ask questions about a PDF using AI
- Chat with PDF docs using AI (quoting sources)
- CV Resume PDF Parsing with Multimodal Vision AI
- Extract and process information directly from PDF using Claude and Gemini
- Extract data from resume and create PDF with Gotenberg
- Extract text from PDF and image using Vertex AI (Gemini) into CSV
- Invoice data extraction with LlamaParse and OpenAI
- Manipulate PDF with Adobe developer API
- Send specific PDF attachments from Gmail to Google Drive using OpenAI
- Telegram chat with PDF

### Pinecone (3 workflows)
- Chat with GitHub API Documentation_ RAG-Powered Chatbot with Pinecone & OpenAI
- Notion to Pinecone Vector Store Integration
- RAG_Context-Aware Chunking _ Google Drive to Pinecone via OpenRouter & Gemini

---

## Q

### Qdrant (10 workflows)
- Automate SIEM Alert Enrichment with MITRE ATT&CK, Qdrant & Zendesk in n8n
- Breakdown Documents into Study Notes using Templating MistralAI and Qdrant
- Build a Financial Documents Assistant using Qdrant and Mistral.ai
- Build a Tax Code Assistant with Qdrant, Mistral.ai and OpenAI
- Building RAG Chatbot for Movie Recommendations with Qdrant and Open AI
- Customer Insights with Qdrant, Python and Information Extractor
- Survey Insights with Qdrant, Python and Information Extractor
- n8n_4_1__Qdrant

---

## R

### RAG (25+ workflows)
- AI-Powered Email Automation for Business_ Summarize & Respond with RAG
- AI-Powered RAG Workflow For Stock Earnings Report Analysis
- AI_ Ask questions about any data source (using the n8n workflow retriever)
- Building RAG Chatbot for Movie Recommendations with Qdrant and Open AI
- Chat with GitHub API Documentation_ RAG-Powered Chatbot with Pinecone & OpenAI
- Complete business WhatsApp AI-Powered RAG Chatbot using OpenAI
- Make OpenAI Citation for File Retrieval RAG
- Personal Shopper Chatbot for WooCommerce with RAG using Google Drive and openAI
- RAG Chatbot for Company Documents using Google Drive and Gemini
- RAG_Context-Aware Chunking _ Google Drive to Pinecone via OpenRouter & Gemini
- V1_Local_RAG_AI_Agent
- V2_Local_Supabase_RAG_AI_Agent
- V3_Local_Agentic_RAG_AI_Agent
- n8n_4_2__c4ai___Local_Supabase_RAG

### Research (5 workflows)
- AI web researcher for sales
- n8n_4_3__Deep_Research
- Open Deep Research - AI-Powered Autonomous Research Workflow
- 🔥📈🤖 AI Agent for n8n Creators Leaderboard - Find Popular Workflows

---

## S

### Scraping (10 workflows)
- AI agent that can scrape webpages
- AI Powered Web Scraping with Jina, Google Sheets and OpenAI _ the EASY way
- Deduplicate Scraping AI Grants for Eligibility using AI
- Hacker News Job Listing Scraper and Parser
- Scrape and summarize posts of a news site without RSS feed using AI and save them to a NocoDB
- Scrape and summarize webpages with AI
- Scrape Trustpilot Reviews with DeepSeek, Analyze Sentiment with OpenAI
- Ultimate Scraper Workflow for n8n
- ✨ Vision-Based AI Agent Scraper - with Google Sheets, ScrapingBee, and Gemini

### SEO (2 workflows)
- Generate SEO Seed Keywords Using AI

### Slack (8 workflows)
- AI-Powered Information Monitoring with OpenAI, Google Sheets, Jina AI and Slack
- Creating a AI Slack Bot with Google Gemini
- Customer Support Channel and Ticketing System with Slack and Linear
- Enhance Security Operations with the Qualys Slack Shortcut Bot!
- Enrich Pipedrive_s Organization Data with OpenAI GPT-4o & Notify it in Slack
- IT Ops AI SlackBot Workflow - Chat with your knowledge base
- Sentiment Analysis Tracking on Support Issues with Linear and Slack
- Slack slash commands AI Chat Bot

### Social Media (20+ workflows)
- AI Social Media Caption Creator creates social media post captions in Airtable
- AI-Powered Social Media Amplifier
- Create dynamic Twitter profile banner
- Generate Instagram Content from Top Trends with AI Image Generation
- Generate___Auto_post_AI_Videos_to_Social_Media_with_Veo3_and_Blotato
- OpenAI-powered tweet generator
- Post New YouTube Videos to X
- Social Media Analysis and Automated Email Generation
- Speed Up Social Media Banners With BannerBear.com
- Twitter Virtual AI Influencer
- Update Twitter banner using HTTP request
- Upload to Instagram and Tiktok from Google Drive

### SQL (5 workflows)
- Generate SQL queries from schema only - AI-powered
- Query n8n Credentials with AI SQL Agent
- Talk to your SQLite database with a LangChain AI Agent
- Visualize your SQL Agent queries with OpenAI and Quickchart.io

### Supabase (10 workflows)
- AI Agent To Chat With Files In Supabase Storage
- AI Agent to chat with Supabase_PostgreSQL DB
- Store Notion_s Pages as Vector Documents into Supabase with OpenAI
- Supabase Insertion & Upsertion & Retrieval
- Supabase Vector Updater
- Telegram Bot with Supabase memory and OpenAI assistant integration
- Upsert huge documents in a vector store with Supabase and Notion
- V2_Local_Supabase_RAG_AI_Agent
- WordPress - AI Chatbot to enhance user experience - with Supabase and OpenAI
- n8n_3_2__c4ai___Local_Supabase
- n8n_4_2__c4ai___Local_Supabase_RAG

---

## T

### Telegram (20+ workflows)
- Agentic Telegram AI bot with with LangChain nodes and new tools
- AI-Powered Children_s Arabic Storytelling on Telegram
- AI-Powered Children_s English Storytelling on Telegram with OpenAI
- Angie, Personal AI Assistant with Telegram Voice and Text
- Automated AI image analysis and response via Telegram
- Chat with OpenAIs GPT via a simple Telegram Bot
- Chat with your event schedule from Google Sheets in Telegram
- Create a Google Analytics Data Report with AI and sent it to E-Mail and Telegram
- Image Creation with OpenAI and Telegram
- Send a random recipe once a day to Telegram
- Telegram AI bot assistant_ ready-made template for voice & text messages
- Telegram AI bot with LangChain nodes
- Telegram AI Bot_ NeurochainAI Text & Image - NeurochainAI Basic API Integration
- Telegram AI Chatbot
- Telegram Bot with Supabase memory and OpenAI assistant integration
- Telegram chat with PDF
- Telegram to Spotify with OpenAI
- Translate Telegram audio messages with AI (55 supported languages)
- n8n_1_1__Telegram_Voice_Agent
- n8n_2_5__Telegram_Long_Term_Memory
- 🐋🤖 DeepSeek AI Agent + Telegram + LONG TERM Memory 🧠
- 🤖 Telegram Messaging Agent for Text_Audio_Images
- 🤖🧠 AI Agent Chatbot + LONG TERM Memory + Note Storage + Telegram

### Transcription (8 workflows)
- Actioning Your Meeting Next Steps using Transcripts and AI
- Daily Podcast Summary
- HR & IT Helpdesk Chatbot with Audio Transcription
- Summarize YouTube Videos from Transcript
- Transcribe Audio Files, Summarize with GPT-4, and Store in Notion
- Transcribing Bank Statements To Markdown Using Gemini Vision AI

### Twitter/X (5 workflows)
- Create dynamic Twitter profile banner
- OpenAI-powered tweet generator
- Post New YouTube Videos to X
- Twitter Virtual AI Influencer
- Update Twitter banner using HTTP request

---

## V

### Vector Database (15 workflows)
- Generating Image Embeddings via Textual Summarisation
- Notion to Pinecone Vector Store Integration
- Store Notion_s Pages as Vector Documents into Supabase with OpenAI
- Supabase Vector Updater
- Upsert huge documents in a vector store with Supabase and Notion
- Vector Database as a Big Data Analysis Tool for AI Agents [1_3 anomaly][1_2 KNN]
- Vector Database as a Big Data Analysis Tool for AI Agents [2_2 KNN]
- Vector Database as a Big Data Analysis Tool for AI Agents [2_3 - anomaly]
- Vector Database as a Big Data Analysis Tool for AI Agents [3_3 - anomaly]

### Video (8 workflows)
- Fully Automated AI Video Generation & Multi-Platform Publishing
- Generate___Auto_post_AI_Videos_to_Social_Media_with_Veo3_and_Blotato
- Hacker News to Video Content
- Narrating over a Video using Multimodal AI
- Visual Regression Testing with Apify and AI Vision Model
- ⚡AI-Powered YouTube Video Summarization & Analysis

### Vision (10 workflows)
- Analyze Suspicious Email Contents with ChatGPT Vision
- Automate Image Validation Tasks using AI Vision
- CV Resume PDF Parsing with Multimodal Vision AI
- Easy Image Captioning with Gemini 1.5 Pro
- Enrich Property Inventory Survey with Image Recognition and AI Agent
- Prompt-based Object Detection with Gemini 2.0
- Transcribing Bank Statements To Markdown Using Gemini Vision AI
- Visual Regression Testing with Apify and AI Vision Model
- ✨ Vision-Based AI Agent Scraper - with Google Sheets, ScrapingBee, and Gemini

---

## W

### Webhook (5 workflows)
- AI Voice Chat using Webhook, Memory Manager, OpenAI, Google Gemini & ElevenLabs
- Bitrix24 Chatbot Application Workflow example with Webhook Integration
- Generate audio from text using OpenAI and Webhook _ Text to Speech Workflow

### WhatsApp (4 workflows)
- Automate Sales Meeting Prep with AI & APIFY Sent To WhatsApp
- Building Your First WhatsApp Chatbot
- Complete business WhatsApp AI-Powered RAG Chatbot using OpenAI
- Respond to WhatsApp Messages with AI Like a Pro!

### WordPress (6 workflows)
- AI-Generated Summary Block for WordPress Posts
- Auto-Categorize blog posts in wordpress using A.I.
- Auto-Tag Blog Posts in WordPress with AI
- Automate Content Generator for WordPress with DeepSeek R1
- WordPress - AI Chatbot to enhance user experience - with Supabase and OpenAI
- Write a WordPress post with AI (starting from a few keywords)

---

## Y

### YouTube (8 workflows)
- AI Youtube Trend Finder Based On Niche
- Automated_YouTube_Video_Scheduling___AI_Metadata_Generation___
- Automate_YouTube_Uploads_with_AI_Generated_Metadata_from_Google_Drive
- Extract insights & analyse YouTube comments via AI Agent chat
- Post New YouTube Videos to X
- Share YouTube Videos with AI Summaries on Discord
- Summarize YouTube Videos from Transcript
- ⚡AI-Powered YouTube Video Summarization & Analysis

---

## Special Characters & Emoji

### 🤖 AI Agent Workflows
- 🐋DeepSeek V3 Chat & R1 Reasoning Quick Start
- 🐋🤖 DeepSeek AI Agent + Telegram + LONG TERM Memory 🧠
- 🔐🦙🤖 Private & Local Ollama Self-Hosted AI Assistant
- 🔥📈🤖 AI Agent for n8n Creators Leaderboard - Find Popular Workflows
- 🤖 Telegram Messaging Agent for Text_Audio_Images
- 🤖🧑_💻 AI Agent for Top n8n Creators Leaderboard Reporting
- 🤖🧠 AI Agent Chatbot + LONG TERM Memory + Note Storage + Telegram

### 📚 Documentation & Learning
- 📚 Auto-generate documentation for n8n workflows with GPT and Docsify

### 🚀 Advanced/Performance
- 🚀 Local Multi-LLM Testing & Performance Tracker

### ⚡ Quick/Fast Workflows
- ⚡AI-Powered YouTube Video Summarization & Analysis

### ✨ Special/Highlight Workflows
- ✨ Vision-Based AI Agent Scraper - with Google Sheets, ScrapingBee, and Gemini

### 🎨 Creative Workflows
- 🎨 Interactive Image Editor with FLUX.1 Fill Tool for Inpainting

### 📈 Business/Analytics
- 📈 Receive Daily Market News from FT.com to your Microsoft outlook inbox

---

## Most Common Integrations (Summary)

1. **OpenAI** - 100+ workflows
2. **Telegram** - 20+ workflows
3. **Google Drive** - 15+ workflows
4. **Google Sheets** - 15+ workflows
5. **Gmail** - 15+ workflows
6. **Airtable** - 12 workflows
7. **Supabase** - 10+ workflows
8. **Notion** - 8 workflows
9. **Slack** - 8 workflows
10. **Qdrant** - 10 workflows

---

*Last updated: October 25, 2025*
*Use Ctrl+F to search for specific keywords*
