# N8N Workflows Complete Analysis

**Total Workflows: 311**
**Analysis Date: October 25, 2025**
**Location: E:\000-GIT REPOSITORIES\N8N-STARTER-KIT\n8n-installer\n8n\backup\workflows**

---

## Executive Summary

Your n8n workflow collection is heavily focused on AI and LLM integration (75% of workflows), with strong emphasis on:
- AI agents and chatbots
- RAG (Retrieval Augmented Generation) implementations
- Email automation and processing
- Social media integrations
- Document and data extraction

---

## Category Breakdown

### 🤖 AI & LLM (233 workflows - 75%)
**Primary Focus:** OpenAI, Claude, Gemini, DeepSeek, Ollama, LangChain integrations

**Top 20 Workflows:**
1. A Very Simple _Human in the Loop_ Email Response System Using AI and IMAP
2. Actioning Your Meeting Next Steps using Transcripts and AI
3. Advanced AI Demo (Presented at AI Developers #14 meetup)
4. Agentic Telegram AI bot with with LangChain nodes and new tools
5. AI agent chat
6. AI agent for Instagram DM_inbox. Manychat + Open AI integration
7. AI Agent for project management and meetings with Airtable and Fireflies
8. AI Agent for realtime insights on meetings
9. AI agent that can scrape webpages
10. AI Agent To Chat With Files In Supabase Storage
11. AI Agent to chat with Supabase_PostgreSQL DB
12. AI Agent to chat with you Search Console Data, using OpenAI and Postgres
13. AI Agent with Ollama for current weather and wiki
14. AI Agent _ Google calendar assistant using OpenAI
15. AI Automated HR Workflow for CV Analysis and Candidate Evaluation
16. AI chat with any data source (using the n8n workflow tool)
17. AI chatbot that can search the web
18. AI Crew to Automate Fundamental Stock Analysis - Q&A Workflow
19. AI Customer feedback sentiment analysis
20. AI Data Extraction with Dynamic Prompts and Airtable

**Key Use Cases:**
- Customer support automation
- Email processing and response
- Document analysis and extraction
- Meeting transcription and action items
- HR and recruitment workflows
- Content generation
- Data analysis and insights

---

### 🔍 RAG & Vector Database (11 workflows)
**Technologies:** Qdrant, Pinecone, Supabase, Embeddings

**All Workflows:**
1. AI-Powered Email Automation for Business_ Summarize & Respond with RAG
2. AI-Powered RAG Workflow For Stock Earnings Report Analysis
3. AI_ Ask questions about any data source (using the n8n workflow retriever)
4. Automate SIEM Alert Enrichment with MITRE ATT&CK, Qdrant & Zendesk in n8n
5. Breakdown Documents into Study Notes using Templating MistralAI and Qdrant
6. Build a Financial Documents Assistant using Qdrant and Mistral.ai
7. Build a Tax Code Assistant with Qdrant, Mistral.ai and OpenAI
8. Building RAG Chatbot for Movie Recommendations with Qdrant and Open AI
9. Chat with GitHub API Documentation_ RAG-Powered Chatbot with Pinecone & OpenAI
10. Complete business WhatsApp AI-Powered RAG Chatbot using OpenAI
11. Customer Insights with Qdrant, Python and Information Extractor
12. Generating Image Embeddings via Textual Summarisation
13. KB Tool - Confluence Knowledge Base
14. LightRAG_Request
15. Make OpenAI Citation for File Retrieval RAG
16. Notion to Pinecone Vector Store Integration
17. Personal Shopper Chatbot for WooCommerce with RAG using Google Drive and openAI
18. RAG Chatbot for Company Documents using Google Drive and Gemini
19. RAG_Context-Aware Chunking _ Google Drive to Pinecone via OpenRouter & Gemini
20. Store Notion_s Pages as Vector Documents into Supabase with OpenAI
21. Survey Insights with Qdrant, Python and Information Extractor
22. Upsert huge documents in a vector store with Supabase and Notion
23. V1_Local_RAG_AI_Agent
24. V2_Local_Supabase_RAG_AI_Agent
25. V3_Local_Agentic_RAG_AI_Agent
26. Vector Database as a Big Data Analysis Tool for AI Agents [1_3 anomaly][1_2 KNN]
27. Vector Database as a Big Data Analysis Tool for AI Agents [2_2 KNN]
28. Vector Database as a Big Data Analysis Tool for AI Agents [2_3 - anomaly]
29. Vector Database as a Big Data Analysis Tool for AI Agents [3_3 - anomaly]
30. WordPress - AI Chatbot to enhance user experience - with Supabase and OpenAI
31. n8n_4_1__Qdrant
32. n8n_4_2__c4ai___Local_Supabase_RAG

---

### 📧 Email Management (Covered in AI & LLM)
**Key Email Workflows:**
- Gmail auto-labeling and categorization
- Email response drafting with AI
- Email summarization
- Suspicious email analysis
- Email-to-task conversion
- Auto-responders

---

### 📱 Social Media (8 workflows)
**Platforms:** Instagram, Twitter/X, TikTok, Discord, Telegram

**All Workflows:**
1. Create dynamic Twitter profile banner
2. OpenAI-powered tweet generator
3. Post New YouTube Videos to X
4. Send a random recipe once a day to Telegram
5. Send daily translated Calvin and Hobbes Comics to Discord
6. Speed Up Social Media Banners With BannerBear.com
7. Twitter Virtual AI Influencer
8. Update Twitter banner using HTTP request
9. Upload to Instagram and Tiktok from Google Drive

---

### 📄 Document & Data Processing (12 workflows)

**All Workflows:**
1. API Schema Extractor
2. Add positive feedback messages to a table in Notion
3. Author and Publish Blog Posts From Google Sheets
4. Automatic Background Removal for Images in Google Drive
5. Automatically_document_and_backup_N8N_workflows
6. Chat with a Google Sheet using AI
7. Get Airtable data via AI and Obsidian Notes
8. Hacker News Job Listing Scraper and Parser
9. Introduction to the HTTP Tool
10. Monthly Spotify Track Archiving and Playlist Classification
11. UTM Link Creator & QR Code Generator with Scheduled Google Analytics Reports
12. Use AI to organize your Todoist Inbox

---

### 🖼️ Image & Video (9 workflows)

**All Workflows:**
1. Fully Automated AI Video Generation & Multi-Platform Publishing
2. Generate 9_16 Images from Content and Brand Guidelines
3. Hacker News to Video Content
4. Post New YouTube Videos to X
5. Summarize YouTube Videos from Transcript
6. Transform Image to Lego Style Using Line and Dall-E
7. Upload to Instagram and Tiktok from Google Drive
8. ⚡AI-Powered YouTube Video Summarization & Analysis
9. 🎨 Interactive Image Editor with FLUX.1 Fill Tool for Inpainting

---

### 🔧 Automation & Backup (6 workflows)

**All Workflows:**
1. Automate testimonials in Strapi with n8n
2. Automated Hugging Face Paper Summary Fetching & Categorization Workflow
3. Automated Workflow Backup System with Google Drive, Gmail and Discord Alerts
4. Automated n8n Workflow Backup to GitHub with Deletion Tracking
5. Backup_all_n8n_workflows_to_Google_Drive_every_4_hours
6. Text automations using Apple Shortcuts

---

### 🎙️ Voice & Audio (1 workflow)
1. Generate Text-to-Speech Using Elevenlabs via API

Note: Many AI workflows include voice capabilities (Telegram voice bots, transcription, etc.)

---

### 🌐 Web Scraping (1 main workflow)
1. Ultimate Scraper Workflow for n8n

Note: Many AI agent workflows include scraping capabilities

---

### 🗄️ Database (3 workflows)
1. Send Google analytics data to A.I. to analyze then save results in Baserow
2. Send Google analytics data to A.I. to analyze then save results in BaserowSend Google analytics data to A.I. to analyze then save results in Baserow
3. n8n_3_4__Redis

---

### 🎯 Customer Support (3 workflows)
1. Customer Support Channel and Ticketing System with Slack and Linear
2. Hacker News Throwback Machine - See What Was Hot on This Day, Every Year!
3. Sentiment Analysis Tracking on Support Issues with Linear and Slack

---

### 📊 Analytics & Reporting (2 workflows)
1. Analyze feedback and send a message on Mattermost
2. Analyze feedback using AWS Comprehend and send it to a Mattermost channel

---

### ✍️ Content Creation (1 workflow)
1. Auto-Categorize blog posts in wordpress using A.I.

---

### 🔹 Other/Utility (21 workflows)

**All Workflows:**
1. Bitrix_Agent
2. Brave_Agent___MCP_1
3. Convert URL HTML to Markdown Format and Get Page Links
4. ETL pipeline for text processing
5. Enhance Security Operations with the Qualys Slack Shortcut Bot!
6. Enhance Customer Chat by Buffering Messages with Twilio and Redis
7. Fetch Dynamic Prompts from GitHub and Auto-Populate n8n Expressions in Prompt
8. Hacker News Throwback Machine - See What Was Hot on This Day, Every Year!
9. Handling Appointment Leads and Follow-up With Twilio, Cal.com and AI
10. Introduction to the HTTP Tool
11. Learn Anything from HN - Get Top Resource Recommendations from Hacker News
12. Reconcile Rent Payments with Local Excel Spreadsheet and OpenAI
13. Send a random recipe once a day to Telegram
14. Supabase Insertion & Upsertion & Retrieval
15. Supabase Vector Updater
16. Text automations using Apple Shortcuts
17. UTM Link Creator & QR Code Generator with Scheduled Google Analytics Reports
18. Use OpenRouter in n8n versions _1.78
19. Using External Workflows as Tools in n8n
20. Venafi Cloud Slack Cert Bot
21. 📈 Receive Daily Market News from FT.com to your Microsoft outlook inbox

---

## Top Integration Platforms

### AI/LLM Providers:
- **OpenAI** (GPT-3.5, GPT-4, DALL-E, Whisper) - Most common
- **Google Gemini** - Growing usage
- **DeepSeek** (V3, R1) - Recent additions
- **Ollama** - Local LLM hosting
- **Claude (Anthropic)** - Several workflows
- **Mistral AI** - Document processing
- **ElevenLabs** - Text-to-speech

### Vector Databases:
- Qdrant
- Pinecone
- Supabase
- Postgres with pgvector

### Communication Platforms:
- **Telegram** - Most popular messaging platform
- **Slack** - Team communication
- **Discord** - Community engagement
- **WhatsApp** - Business communication
- **LINE** - Asian market focus

### Data & Storage:
- **Google Drive** - File storage
- **Google Sheets** - Data management
- **Airtable** - Database workflows
- **Notion** - Knowledge base
- **Baserow** - Open-source database
- **Supabase** - Backend platform

### Content Platforms:
- WordPress
- YouTube
- Instagram
- Twitter/X
- TikTok

---

## Notable Workflow Patterns

### 1. RAG Implementations (32 workflows)
Advanced retrieval-augmented generation for:
- Company knowledge bases
- Document Q&A systems
- Customer support automation
- Financial analysis
- Tax code assistance

### 2. Telegram AI Bots (15+ workflows)
- Voice and text message handling
- Long-term memory integration
- Multi-modal capabilities (text, audio, images)
- Integration with various AI providers

### 3. Email Automation (20+ workflows)
- Auto-categorization and labeling
- AI-powered responses
- Suspicious email detection
- Email-to-task conversion
- Summary generation

### 4. HR & Recruitment (8+ workflows)
- CV/Resume parsing and analysis
- Candidate screening
- Job posting automation
- Application evaluation

### 5. Meeting Intelligence (5+ workflows)
- Transcription and summarization
- Action item extraction
- Calendar integration
- Follow-up automation

### 6. Content Generation (15+ workflows)
- Blog post creation
- Social media captions
- SEO keyword generation
- Video metadata
- Image generation

---

## Special Workflow Series

### n8n Series Workflows:
1. **n8n_1_1** - Image & Voice basics
2. **n8n_2_x** - Notion, Sheets, Airtable integrations
3. **n8n_3_x** - Advanced tools (SearXNG, Perplexity, GraphQL, Redis, Replicate, Flux)
4. **n8n_4_x** - RAG implementations (Qdrant, Supabase, Deep Research)

### Local AI Series:
1. V1_Local_RAG_AI_Agent
2. V2_Local_Supabase_RAG_AI_Agent
3. V3_Local_Agentic_RAG_AI_Agent

---

## Advanced Features

### Multi-Modal AI:
- Vision-based analysis (Gemini Vision, GPT-4 Vision)
- Audio transcription and processing
- Image generation and editing
- Video narration

### Memory & Context:
- Long-term memory systems
- Vector database integration
- Conversation history management
- Context-aware responses

### Agentic Workflows:
- Tool-using AI agents
- Multi-step reasoning
- External API integration
- Autonomous task execution

---

## Unique & Innovative Workflows

1. **🚀 Local Multi-LLM Testing & Performance Tracker** - Compare multiple LLM providers
2. **Kids_Story_Building_System_v1_0_0** - Interactive storytelling for children
3. **Siri AI Agent_ Apple Shortcuts powered voice template** - iOS integration
4. **Proxmox AI Agent** - Infrastructure management with AI
5. **Spot Workplace Discrimination Patterns with AI** - HR analytics
6. **Visual Regression Testing with Apify and AI Vision Model** - QA automation
7. **Detect hallucinations using specialised Ollama model bespoke-minicheck** - AI validation
8. **Twitter Virtual AI Influencer** - Autonomous social media presence

---

## Search Index

### By Functionality:
- **Customer Service**: 15+ workflows
- **Data Extraction**: 20+ workflows  
- **Email Processing**: 25+ workflows
- **Image Generation**: 12+ workflows
- **Meeting Management**: 8+ workflows
- **PDF Processing**: 10+ workflows
- **Research & Analysis**: 15+ workflows
- **Social Media**: 20+ workflows
- **Transcription**: 8+ workflows
- **Web Scraping**: 10+ workflows

### By Platform:
- **Airtable**: 12 workflows
- **Discord**: 5 workflows
- **GitHub**: 4 workflows
- **Google Drive**: 15+ workflows
- **Google Sheets**: 15+ workflows
- **Notion**: 10+ workflows
- **Slack**: 8 workflows
- **Supabase**: 12 workflows
- **Telegram**: 20+ workflows
- **WordPress**: 8 workflows

---

## Recommendations

### Quick Wins:
1. Start with basic AI chatbots (Telegram, Slack)
2. Implement email auto-labeling
3. Set up workflow backups
4. Try simple RAG implementations

### Advanced Projects:
1. Build custom AI agents with tools
2. Implement multi-modal processing
3. Create agentic RAG systems
4. Deploy local LLM solutions

### Learning Path:
1. **Beginner**: Simple chatbots and email automation
2. **Intermediate**: RAG systems and vector databases
3. **Advanced**: Agentic AI and multi-step workflows
4. **Expert**: Custom tool integration and multi-modal systems

---

## File Organization

**Main Directory Structure:**
```
E:\000-GIT REPOSITORIES\N8N-STARTER-KIT\n8n-installer\n8n\backup\workflows\
├── 311 workflow JSON files
└── .gitkeep
```

**File Naming Patterns:**
- Descriptive names with use case
- Some with emoji prefixes (🤖, 📚, 🔥, etc.)
- Version indicators (V1, V2, V3)
- Series indicators (n8n_X_Y)

---

## Next Steps

1. **Explore** specific workflows by category
2. **Test** basic workflows first
3. **Customize** for your use cases
4. **Integrate** with your existing tools
5. **Monitor** performance and iterate

---

*Analysis generated on October 25, 2025*
*Total workflows analyzed: 311*
